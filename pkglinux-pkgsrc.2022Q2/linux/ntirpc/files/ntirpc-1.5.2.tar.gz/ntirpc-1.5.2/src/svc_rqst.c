/*
 * Copyright (c) 2012 Linux Box Corporation.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR `AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include <config.h>

#include <sys/types.h>
#include <sys/poll.h>
#include <stdint.h>
#include <assert.h>
#include <err.h>
#include <errno.h>
#include <unistd.h>
#include <fcntl.h>
#include <signal.h>

#include <rpc/types.h>
#include <misc/portable.h>
#include <rpc/rpc.h>
#ifdef PORTMAP
#include <rpc/pmap_clnt.h>
#endif				/* PORTMAP */
#include <rpc/svc_rqst.h>

#include "rpc_com.h"

#include <rpc/svc.h>
#include <misc/rbtree_x.h>
#include <misc/opr_queue.h>
#include "clnt_internal.h"
#include "svc_internal.h"
#include <rpc/svc_rqst.h>
#include "svc_xprt.h"

/*
 * The TI-RPC instance should be able to reach every registered
 * handler, and potentially each SVCXPRT registered on it.
 *
 * Each SVCXPRT points to its own handler, however, so operations to
 * block/unblock events (for example) given an existing xprt handle
 * are O(1) without any ordered or hashed representation.
 */

#define SVC_RQST_PARTITIONS 7

static bool initialized;

struct svc_rqst_set {
	mutex_t mtx;
	struct rbtree_x xt;
	uint32_t next_id;
};

static struct svc_rqst_set svc_rqst_set = {
	MUTEX_INITIALIZER,	/* mtx */
	{
	 0,			/* npart */
	 RBT_X_FLAG_NONE,	/* flags */
	 23,			/* cachesz */
	 NULL			/* tree */
	},			/* xt */
	0			/* next_id */
};

struct svc_rqst_rec {
	struct opr_rbtree_node node_k;
	TAILQ_HEAD(evq_head, rpc_svcxprt) xprt_q;	/* xprt handles */
	pthread_mutex_t mtx;
	void *u_data;		/* user-installable opaque data */
	uint64_t gen;		/* generation number */

	int sv[2];
	uint32_t id_k;		/* chan id */
	uint32_t states;
	uint32_t signals;
	uint32_t refcnt;
	uint16_t flags;

	/*
	 * union of event processor types
	 */
	enum svc_event_type ev_type;
	union {
#if defined(TIRPC_EPOLL)
		struct {
			int epoll_fd;
			struct epoll_event ctrl_ev;
			struct epoll_event *events;
			u_int max_events;	/* max epoll events */
		} epoll;
#endif
		struct {
			fd_set set;	/* select/fd_set (currently unhooked) */
		} fd;
	} ev_u;
};

static inline int rqst_thrd_cmpf(const struct opr_rbtree_node *lhs,
				 const struct opr_rbtree_node *rhs)
{
	struct svc_rqst_rec *lk, *rk;

	lk = opr_containerof(lhs, struct svc_rqst_rec, node_k);
	rk = opr_containerof(rhs, struct svc_rqst_rec, node_k);

	if (lk->id_k < rk->id_k)
		return (-1);

	if (lk->id_k == rk->id_k)
		return (0);

	return (1);
}

static inline void
SetNonBlock(int fd)
{
	int s_flags = fcntl(fd, F_GETFL, 0);
	(void)fcntl(fd, F_SETFL, (s_flags | O_NONBLOCK));
}

int
svc_rqst_init(void)
{
	int ix, code = 0;

	mutex_lock(&svc_rqst_set.mtx);

	if (initialized)
		goto unlock;

	code = rbtx_init(&svc_rqst_set.xt, rqst_thrd_cmpf, SVC_RQST_PARTITIONS,
			 RBT_X_FLAG_ALLOC | RBT_X_FLAG_CACHE_RT);
	if (code) {
		__warnx(TIRPC_DEBUG_FLAG_ERROR,
			"%s: rbtx_init failed (%d)",
			__func__, code);
		goto unlock;
	}

	/* init read-through cache */
	for (ix = 0; ix < SVC_RQST_PARTITIONS; ++ix) {
		struct rbtree_x_part *xp = &(svc_rqst_set.xt.tree[ix]);

		xp->cache = mem_calloc(svc_rqst_set.xt.cachesz,
					sizeof(struct opr_rbtree_node *));
	}
	initialized = true;

 unlock:
	mutex_unlock(&svc_rqst_set.mtx);
	return (code);
}

static inline bool
svc_rqst_init_failure(void)
{
	if (initialized)
		return (false);
	return (svc_rqst_init() != 0);
}

/**
 * @brief Lookup a channel
 * @note Locking
 * - SVC_RQST_FLAG_PART_UNLOCK - Unlock the tree partition before returning.
 *   Otherwise, it is returned locked.
 * - Returns with sr_rec locked.
 */
static inline struct svc_rqst_rec *
svc_rqst_lookup_chan(uint32_t chan_id, struct rbtree_x_part **ref_t,
		     uint32_t flags)
{
	struct svc_rqst_rec trec;
	struct rbtree_x_part *t;
	struct opr_rbtree_node *ns;
	struct svc_rqst_rec *sr_rec = NULL;

	if (svc_rqst_init_failure())
		return (NULL);

	trec.id_k = chan_id;
	t = rbtx_partition_of_scalar(&svc_rqst_set.xt, trec.id_k);
	*ref_t = t;

	mutex_lock(&t->mtx);

	ns = rbtree_x_cached_lookup(&svc_rqst_set.xt, t, &trec.node_k,
				    trec.id_k);
	if (ns) {
		sr_rec = opr_containerof(ns, struct svc_rqst_rec, node_k);
		mutex_lock(&sr_rec->mtx);
		++(sr_rec->refcnt);
	}

	if (flags & SVC_RQST_FLAG_PART_UNLOCK)
		mutex_unlock(&t->mtx);

	return (sr_rec);
}

int
svc_rqst_new_evchan(uint32_t *chan_id /* OUT */, void *u_data, uint32_t flags)
{
	struct svc_rqst_rec *sr_rec;
	struct rbtree_x_part *t;
	uint32_t n_id;
	bool rslt __attribute__ ((unused));
	int code = 0;

	if (svc_rqst_init_failure())
		return (EINVAL);

	flags |= SVC_RQST_FLAG_EPOLL;	/* XXX */

	sr_rec = mem_zalloc(sizeof(struct svc_rqst_rec));

	/* create a pair of anonymous sockets for async event channel wakeups */
	code = socketpair(AF_UNIX, SOCK_STREAM, 0, sr_rec->sv);
	if (code) {
		__warnx(TIRPC_DEBUG_FLAG_ERROR,
			"%s: failed creating event signal socketpair (%d)",
			__func__, code);
		mem_free(sr_rec, sizeof(struct svc_rqst_rec));
		return (code);
	}

	/* set non-blocking */
	SetNonBlock(sr_rec->sv[0]);
	SetNonBlock(sr_rec->sv[1]);

#if defined(TIRPC_EPOLL)
	if (flags & SVC_RQST_FLAG_EPOLL) {

		sr_rec->flags = flags & SVC_RQST_FLAG_MASK;

		sr_rec->ev_type = SVC_EVENT_EPOLL;

		/* XXX improve this too */
		sr_rec->ev_u.epoll.max_events =
		    __svc_params->ev_u.evchan.max_events;
		sr_rec->ev_u.epoll.events = (struct epoll_event *)
		    mem_alloc(sr_rec->ev_u.epoll.max_events *
			      sizeof(struct epoll_event));

		/* create epoll fd */
		sr_rec->ev_u.epoll.epoll_fd =
		    epoll_create_wr(sr_rec->ev_u.epoll.max_events,
				    EPOLL_CLOEXEC);

		if (sr_rec->ev_u.epoll.epoll_fd == -1) {
			__warnx(TIRPC_DEBUG_FLAG_ERROR,
				"%s: epoll_create failed (%d)", __func__,
				errno);
			mem_free(sr_rec->ev_u.epoll.events,
				 sr_rec->ev_u.epoll.max_events *
				 sizeof(struct epoll_event));
			mem_free(sr_rec, sizeof(struct svc_rqst_rec));
			return (EINVAL);
		}

		/* permit wakeup of threads blocked in epoll_wait, with a
		 * couple of possible semantics */
		sr_rec->ev_u.epoll.ctrl_ev.events =
		    EPOLLIN | EPOLLRDHUP;
		sr_rec->ev_u.epoll.ctrl_ev.data.fd = sr_rec->sv[1];
		code =
		    epoll_ctl(sr_rec->ev_u.epoll.epoll_fd, EPOLL_CTL_ADD,
			      sr_rec->sv[1], &sr_rec->ev_u.epoll.ctrl_ev);
		if (code == -1)
			__warnx(TIRPC_DEBUG_FLAG_ERROR,
				"%s: add control socket failed (%d)", __func__,
				errno);
	} else {
		/* legacy fdset (currently unhooked) */
		sr_rec->ev_type = SVC_EVENT_FDSET;
	}
#else
	sr_rec->ev_type = SVC_EVENT_FDSET;
#endif

	n_id = atomic_inc_uint32_t(&svc_rqst_set.next_id);

	sr_rec->id_k = n_id;
	sr_rec->states = SVC_RQST_STATE_NONE;
	sr_rec->u_data = u_data;
	sr_rec->refcnt = 1;	/* svc_rqst_set ref */
	sr_rec->gen = 0;
	mutex_init(&sr_rec->mtx, NULL);
	TAILQ_INIT(&sr_rec->xprt_q);

	t = rbtx_partition_of_scalar(&svc_rqst_set.xt, sr_rec->id_k);
	mutex_lock(&t->mtx);
	rslt =
	    rbtree_x_cached_insert(&svc_rqst_set.xt, t, &sr_rec->node_k,
				   sr_rec->id_k);
	mutex_unlock(&t->mtx);

	__warnx(TIRPC_DEBUG_FLAG_SVC_RQST,
		"%s: create evchan %d socketpair %d:%d", __func__, n_id,
		sr_rec->sv[0], sr_rec->sv[1]);

	*chan_id = n_id;
	return (code);
}

/*
 * Write 4-byte value to shared event-notification channel.  The
 * value as presently implemented can be interpreted only by one consumer,
 * so is not relied on.
 */
static inline void
ev_sig(int fd, uint32_t sig)
{
	int code = write(fd, &sig, sizeof(uint32_t));
	__warnx(TIRPC_DEBUG_FLAG_SVC_RQST, "%s: fd %d sig %d", __func__, fd,
		sig);
	if (code < 1)
		__warnx(TIRPC_DEBUG_FLAG_SVC_RQST,
			"%s: error writing to event socket (%d:%d)", __func__,
			code, errno);
}

/*
 * Read a single 4-byte value from the shared event-notification channel,
 * the socket is in non-blocking mode.  The value read is returned.
 */
static inline uint32_t
consume_ev_sig_nb(int fd)
{
	uint32_t sig = 0;
	int code __attribute__ ((unused));

	code = read(fd, &sig, sizeof(uint32_t));
	return (sig);
}

static inline void
svc_rqst_release(struct svc_rqst_rec *sr_rec /* LOCKED => UNLOCKED */)
{
	uint32_t refcnt;

	refcnt = --(sr_rec->refcnt);

	mutex_unlock(&sr_rec->mtx);

	if (refcnt == 0) {
		/* assert sr_rec DESTROYED */
		mutex_destroy(&sr_rec->mtx);
		mem_free(sr_rec, sizeof(struct svc_rqst_rec));
	}
}

static inline int
svc_rqst_unhook_events(SVCXPRT *xprt, struct svc_rqst_rec *sr_rec /* LOCKED */)
{
	int code = 0;

	switch (sr_rec->ev_type) {
#if defined(TIRPC_EPOLL)
	case SVC_EVENT_EPOLL:
	{
		struct epoll_event *ev = &xprt->ev_u.epoll.event;

		/* clear epoll vector */
		code = epoll_ctl(sr_rec->ev_u.epoll.epoll_fd,
				 EPOLL_CTL_DEL, xprt->xp_fd, ev);
		if (code) {
			__warnx(TIRPC_DEBUG_FLAG_ERROR,
				"%s: %p epoll del failed fd %d "
				"sr_rec %p epoll_fd %d "
				"control fd pair (%d:%d) (%d, %d)",
				__func__, xprt, xprt->xp_fd,
				sr_rec, sr_rec->ev_u.epoll.epoll_fd,
				sr_rec->sv[0], sr_rec->sv[1],
				code, errno);
			code = errno;
		} else {
			__warnx(TIRPC_DEBUG_FLAG_SVC_RQST,
				"%s: %p epoll del fd %d "
				"sr_rec %p epoll_fd %d "
				"control fd pair (%d:%d) (%d, %d)",
				__func__, xprt, xprt->xp_fd,
				sr_rec, sr_rec->ev_u.epoll.epoll_fd,
				sr_rec->sv[0], sr_rec->sv[1],
				code, errno);
		}
		break;
	}
#endif
	default:
		/* XXX formerly select/fd_set case, now placeholder for new
		 * event systems, reworked select, etc. */
		break;
	}			/* switch */

	return (code);
}

int
svc_rqst_rearm_events(SVCXPRT *xprt, uint32_t __attribute__ ((unused)) flags)
{
	struct svc_rqst_rec *sr_rec = (struct svc_rqst_rec *)xprt->xp_ev;
	int code = 0;

	if (svc_rqst_init_failure())
		return (EINVAL);

	if (xprt->xp_flags & SVC_XPRT_FLAG_DESTROYED)
		return (0);

	/* MUST follow the destroyed check above */
	if (sr_rec->states & SVC_RQST_STATE_DESTROYED)
		return (0);

	mutex_lock(&sr_rec->mtx);
	if (atomic_fetch_uint16_t(&xprt->xp_flags) & SVC_XPRT_FLAG_ADDED) {

		switch (sr_rec->ev_type) {
#if defined(TIRPC_EPOLL)
		case SVC_EVENT_EPOLL:
		{
			struct epoll_event *ev = &xprt->ev_u.epoll.event;

			/* set up epoll user data */
			/* ev->data.ptr = xprt; *//* XXX already set */
			ev->events = EPOLLIN | EPOLLONESHOT;

			/* rearm in epoll vector */
			code = epoll_ctl(sr_rec->ev_u.epoll.epoll_fd,
					 EPOLL_CTL_MOD, xprt->xp_fd, ev);

			__warnx(TIRPC_DEBUG_FLAG_SVC_RQST,
				"%s: %p epoll arm fd %d "
				"sr_rec %p epoll_fd %d "
				"control fd pair (%d:%d) (%d, %d)",
				__func__, xprt, xprt->xp_fd,
				sr_rec, sr_rec->ev_u.epoll.epoll_fd,
				sr_rec->sv[0], sr_rec->sv[1],
				code, errno);
			break;
		}
#endif
		default:
			/* XXX formerly select/fd_set case, now placeholder
			 * for new event systems, reworked select, etc. */
			break;
		}		/* switch */
	}

	mutex_unlock(&sr_rec->mtx);
	return (code);
}

static inline int
svc_rqst_hook_events(SVCXPRT *xprt, struct svc_rqst_rec *sr_rec /* LOCKED */)
{
	int code = 0;

	switch (sr_rec->ev_type) {
#if defined(TIRPC_EPOLL)
	case SVC_EVENT_EPOLL:
	{
		struct epoll_event *ev = &xprt->ev_u.epoll.event;

		/* set up epoll user data */
		ev->data.ptr = xprt;

		/* wait for read events, level triggered, oneshot */
		ev->events = EPOLLIN | EPOLLONESHOT;

		/* add to epoll vector */
		code = epoll_ctl(sr_rec->ev_u.epoll.epoll_fd,
				 EPOLL_CTL_ADD, xprt->xp_fd, ev);
		if (code) {
			__warnx(TIRPC_DEBUG_FLAG_ERROR,
				"%s: %p epoll add failed fd %d "
				"sr_rec %p epoll_fd %d "
				"control fd pair (%d:%d) (%d, %d)",
				__func__, xprt, xprt->xp_fd,
				sr_rec, sr_rec->ev_u.epoll.epoll_fd,
				sr_rec->sv[0], sr_rec->sv[1],
				code, errno);
			code = errno;
		} else {
			atomic_set_uint16_t_bits(&xprt->xp_flags,
						 SVC_XPRT_FLAG_ADDED);

			__warnx(TIRPC_DEBUG_FLAG_SVC_RQST,
				"%s: %p epoll add fd %d "
				"sr_rec %p epoll_fd %d "
				"control fd pair (%d:%d) (%d, %d)",
				__func__, xprt, xprt->xp_fd,
				sr_rec, sr_rec->ev_u.epoll.epoll_fd,
				sr_rec->sv[0], sr_rec->sv[1],
				code, errno);
		}
		break;
	}
#endif
	default:
		/* XXX formerly select/fd_set case, now placeholder for new
		 * event systems, reworked select, etc. */
		break;
	}			/* switch */

	ev_sig(sr_rec->sv[0], 0);	/* send wakeup */

	return (code);
}

/*
 * indirect on xp_ev and xp_evq protected by sr_rec lock
 */
static void
svc_rqst_unreg(SVCXPRT *xprt, struct svc_rqst_rec *sr_rec /* LOCKED */)
{
	uint16_t xp_flags = atomic_postclear_uint16_t_bits(&xprt->xp_flags,
							   SVC_XPRT_FLAG_ADDED);

	/* clear events */
	if (xp_flags & SVC_XPRT_FLAG_ADDED)
		(void)svc_rqst_unhook_events(xprt, sr_rec);

	TAILQ_REMOVE(&sr_rec->xprt_q, xprt, xp_evq);

	__warnx(TIRPC_DEBUG_FLAG_REFCNT | TIRPC_DEBUG_FLAG_SVC_RQST,
		"%s: %p xp_refs %" PRIu32
		" chan_id %d refcnt %" PRIu32,
		__func__, xprt, xprt->xp_refs,
		sr_rec->id_k, sr_rec->refcnt);

	/* Unlinking after debug message ensures both the xprt and the sr_rec
	 * are still present, as the xprt unregisters before release.
	 */
	xprt->xp_ev = NULL;

	/* DROP one ref per xprt, but need no release here;
	 * by definition, there is always another partition ref.
	 */
	--(sr_rec->refcnt);
}

int
svc_rqst_evchan_reg(uint32_t chan_id, SVCXPRT *xprt, uint32_t flags)
{
	struct svc_rqst_rec *sr_rec;
	struct svc_rqst_rec *xp_ev;
	struct rbtree_x_part *t;
	int code;

	if (chan_id == 0) {
		if (__svc_params->ev_u.evchan.id) {
			__warnx(TIRPC_DEBUG_FLAG_ERROR,
				"%s: %p called with chan_id 0, but global/legacy event channel already exists (bug)",
				__func__, xprt);
			return (EINVAL);
		}
		/* Create a global/legacy event channel */
		code = svc_rqst_new_evchan(&(__svc_params->ev_u.evchan.id),
					   NULL /* u_data */ ,
					   SVC_RQST_FLAG_CHAN_AFFINITY);
		if (code) {
			__warnx(TIRPC_DEBUG_FLAG_ERROR,
				"%s: %p failed to create global/legacy channel (%d)",
				__func__, xprt, code);
			return (code);
		}
		chan_id = __svc_params->ev_u.evchan.id;
	}

	sr_rec = svc_rqst_lookup_chan(chan_id, &t, SVC_RQST_FLAG_PART_UNLOCK);
	if (!sr_rec) {
		__warnx(TIRPC_DEBUG_FLAG_ERROR,
			"%s: %p unknown chan_id %d",
			__func__, xprt, chan_id);
		return (ENOENT);
	}

	while ((xp_ev = (struct svc_rqst_rec *)xprt->xp_ev) != NULL) {
		if (xp_ev == sr_rec) {
			mutex_unlock(&sr_rec->mtx);
			__warnx(TIRPC_DEBUG_FLAG_SVC_RQST,
				"%s: %p already registered chan_id %d",
				__func__, xprt, chan_id);
			return (0);
		}
		mutex_lock(&xp_ev->mtx);
		if (xp_ev == (struct svc_rqst_rec *)xprt->xp_ev)
			svc_rqst_unreg(xprt, xp_ev);
		mutex_unlock(&xp_ev->mtx);
	}

	if (flags & SVC_XPRT_FLAG_UREG)
		atomic_set_uint16_t_bits(&xprt->xp_flags, SVC_XPRT_FLAG_UREG);

	TAILQ_INSERT_TAIL(&sr_rec->xprt_q, xprt, xp_evq);

	/* link from xprt */
	xprt->xp_ev = sr_rec;

	/* register on event channel */
	(void)svc_rqst_hook_events(xprt, sr_rec);

	__warnx(TIRPC_DEBUG_FLAG_REFCNT | TIRPC_DEBUG_FLAG_SVC_RQST,
		"%s: %p xp_refs %" PRIu32
		" chan_id %d refcnt %" PRIu32,
		__func__, xprt, xprt->xp_refs,
		sr_rec->id_k, sr_rec->refcnt);

	/* Unlocking after debug message ensures both the xprt and the sr_rec
	 * are still present, as the xprt unregisters before release.
	 */
	mutex_unlock(&sr_rec->mtx);

	return (0);
}

/* register newxprt on an event channel, based on various
 * parameters */
int
svc_rqst_xprt_register(SVCXPRT *xprt, SVCXPRT *newxprt)
{
	struct svc_rqst_rec *sr_rec;

	if (svc_rqst_init_failure())
		return (EINVAL);

	/* use global registration if no parent xprt */
	if (!xprt)
		return svc_rqst_evchan_reg(__svc_params->ev_u.evchan.id,
					   newxprt,
					   SVC_RQST_FLAG_CHAN_AFFINITY);

	sr_rec = (struct svc_rqst_rec *)xprt->xp_ev;

	/* or if parent xprt has no dedicated event channel */
	if (!sr_rec)
		return svc_rqst_evchan_reg(__svc_params->ev_u.evchan.id,
					   newxprt,
					   SVC_RQST_FLAG_CHAN_AFFINITY);

	/* follow policy if applied.  the client code will still normally
	 * be called back to, e.g., adjust channel assignment */
	if (!(sr_rec->flags & SVC_RQST_FLAG_CHAN_AFFINITY))
		return svc_rqst_evchan_reg(__svc_params->ev_u.evchan.id,
					   newxprt,
					   SVC_RQST_FLAG_CHAN_AFFINITY);

	return svc_rqst_evchan_reg(sr_rec->id_k, newxprt, SVC_RQST_FLAG_NONE);
}

void
svc_rqst_xprt_unregister(SVCXPRT *xprt)
{
	struct svc_rqst_rec *xp_ev;

	while ((xp_ev = (struct svc_rqst_rec *)xprt->xp_ev) != NULL) {
		mutex_lock(&xp_ev->mtx);
		if (xp_ev == (struct svc_rqst_rec *)xprt->xp_ev)
			svc_rqst_unreg(xprt, xp_ev);
		mutex_unlock(&xp_ev->mtx);
	}

	/* remove xprt from xprt table */
	svc_xprt_clear(xprt, RPC_DPLX_FLAG_UNLOCK);
}

bool_t __svc_clean_idle2(int timeout, bool_t cleanblock);

#ifdef TIRPC_EPOLL

static inline void
svc_rqst_handle_event(struct svc_rqst_rec *sr_rec, struct epoll_event *ev,
		      uint32_t wakeups)
{
	SVCXPRT *xprt = (SVCXPRT *) ev->data.ptr;
	int code __attribute__ ((unused));

	if (ev->data.fd != sr_rec->sv[1]) {
		uint16_t xp_flags = atomic_fetch_uint16_t(&xprt->xp_flags);

		if (!(xp_flags & SVC_XPRT_FLAG_DESTROYED)
		 && (xp_flags & SVC_XPRT_FLAG_ADDED)
		 && (xprt->xp_refs > 0)) {
			/* check for valid xprt. No need for lock;
			 * (idempotent) xp_flags and xp_refs are set atomic.
			 */
			__warnx(TIRPC_DEBUG_FLAG_REFCNT |
				TIRPC_DEBUG_FLAG_SVC_RQST,
				"%s: %p xp_refs %" PRIu32
				" fd %d or ptr %p EPOLL event %d",
				__func__, xprt, xprt->xp_refs,
				ev->data.fd, ev->data.ptr, ev->events);

			/* take extra ref, callout will release */
			SVC_REF(xprt, SVC_REF_FLAG_NONE);

			/* ! LOCKED */
			code = xprt->xp_ops->xp_getreq(xprt);
			__warnx(TIRPC_DEBUG_FLAG_REFCNT,
				"%s: %p xp_refs %" PRIu32
				" post xp_getreq",
				__func__, xprt,
				xprt->xp_refs);
		}
		/* XXX failsafe idle processing */
		if ((wakeups % 1000) == 0)
			__svc_clean_idle2(__svc_params->idle_timeout, true);
	} else {
		/* signalled -- there was a wakeup on ctrl_ev (see
		 * top-of-loop) */
		__warnx(TIRPC_DEBUG_FLAG_SVC_RQST,
			"%s: wakeup fd %d (sr_rec %p)",
			__func__, sr_rec->sv[1],
			sr_rec);
		(void)consume_ev_sig_nb(sr_rec->sv[1]);
		__warnx(TIRPC_DEBUG_FLAG_SVC_RQST,
			"%s: after consume sig fd %d (sr_rec %p)",
			__func__, sr_rec->sv[1],
			sr_rec);
	}
}

/*
 * - sr_rec LOCKED
 *  (sr_rec unlocked during loop).
 * - Returns with sr_rec locked.
 */
static inline int
svc_rqst_thrd_run_epoll(struct svc_rqst_rec *sr_rec, uint32_t
			__attribute__ ((unused)) flags)
{
	struct epoll_event *ev;
	int ix, code = 0;
	int timeout_ms = 120 * 1000;	/* XXX */
	int n_events;
	static uint32_t wakeups;

	for (;;) {
		++(wakeups);

		/* check for signals */
		if (sr_rec->signals & SVC_RQST_SIGNAL_SHUTDOWN)
			break;

		if (sr_rec->states & SVC_RQST_STATE_DESTROYED)
			break;

		mutex_unlock(&sr_rec->mtx);

		__warnx(TIRPC_DEBUG_FLAG_SVC_RQST,
			"%s: before epoll_wait fd %d", __func__,
			sr_rec->ev_u.epoll.epoll_fd);

		switch (n_events =
			epoll_wait(sr_rec->ev_u.epoll.epoll_fd,
				   sr_rec->ev_u.epoll.events,
				   sr_rec->ev_u.epoll.max_events, timeout_ms)) {
		case -1:
			if (errno == EINTR)
				break;
			__warnx(TIRPC_DEBUG_FLAG_SVC_RQST,
				"%s: epoll_wait failed %d", __func__, errno);
			break;
		case 0:
			/* timed out (idle) */
			__svc_clean_idle2(__svc_params->idle_timeout, true);
			break;
		default:
			/* new events */
			for (ix = 0; ix < n_events; ++ix) {
				ev = &(sr_rec->ev_u.epoll.events[ix]);
				svc_rqst_handle_event(sr_rec, ev, wakeups);
			}
		}

		mutex_lock(&sr_rec->mtx);
	}

	return (code);
}
#endif

int
svc_rqst_thrd_run(uint32_t chan_id, __attribute__ ((unused)) uint32_t flags)
{
	struct svc_rqst_rec *sr_rec;
	struct rbtree_x_part *t;
	int code = 0;

	sr_rec = svc_rqst_lookup_chan(chan_id, &t, (SVC_RQST_FLAG_PART_UNLOCK));
	if (!sr_rec) {
		__warnx(TIRPC_DEBUG_FLAG_ERROR,
			"%s: unknown chan_id %d",
			__func__, chan_id);
		return (ENOENT);
	}

	/* serialization model for srec is mutual exclusion on mutation only,
	 * with a secondary state machine to detect inconsistencies (e.g.,
	 * trying to unregister a channel when it is active) */
	sr_rec->states |= SVC_RQST_STATE_ACTIVE;

	/* enter event loop */
	switch (sr_rec->ev_type) {
#if defined(TIRPC_EPOLL)
	case SVC_EVENT_EPOLL:
		code = svc_rqst_thrd_run_epoll(sr_rec, flags);
		break;
#endif
	default:
		/* XXX formerly select/fd_set case, now placeholder for new
		 * event systems, reworked select, etc. */
		__warnx(TIRPC_DEBUG_FLAG_ERROR,
			"%s: unsupported event type",
			__func__);
		break;
	}			/* switch */

	svc_rqst_release(sr_rec);
	return (code);
}

int
svc_rqst_thrd_signal(uint32_t chan_id, uint32_t flags)
{
	struct svc_rqst_rec *sr_rec;
	struct rbtree_x_part *t;

	sr_rec = svc_rqst_lookup_chan(chan_id, &t, SVC_RQST_FLAG_PART_UNLOCK);
	if (!sr_rec) {
		__warnx(TIRPC_DEBUG_FLAG_ERROR,
			"%s: unknown chan_id %d",
			__func__, chan_id);
		return (ENOENT);
	}

	sr_rec->signals |= (flags & SVC_RQST_SIGNAL_MASK);
	ev_sig(sr_rec->sv[0], flags);	/* send wakeup */

	svc_rqst_release(sr_rec);
	return (0);
}

static int
svc_rqst_delete_evchan(uint32_t chan_id)
{
	struct svc_rqst_rec *sr_rec;
	struct rbtree_x_part *t;
	SVCXPRT *next;
	SVCXPRT *xprt;
	int code = 0;

	sr_rec = svc_rqst_lookup_chan(chan_id, &t, SVC_XPRT_FLAG_NONE);
	if (!sr_rec) {
		mutex_unlock(&t->mtx);
		return (ENOENT);
	}

	/* traverse sr_req->xprt_q inorder */
	/* sr_rec LOCKED */
	xprt = TAILQ_FIRST(&sr_rec->xprt_q);

	while (xprt) {
		next = TAILQ_NEXT(xprt, xp_evq);

		svc_rqst_unreg(xprt, sr_rec);

		/* wake up */
		ev_sig(sr_rec->sv[0], 0);
		switch (sr_rec->ev_type) {
#if defined(TIRPC_EPOLL)
		case SVC_EVENT_EPOLL:
			code =
			    epoll_ctl(sr_rec->ev_u.epoll.epoll_fd,
				      EPOLL_CTL_DEL, sr_rec->sv[1],
				      &sr_rec->ev_u.epoll.ctrl_ev);
			if (code == -1)
				__warnx(TIRPC_DEBUG_FLAG_SVC_RQST,
					"%s: epoll del control socket failed (%d)",
					__func__, errno);
			break;
#endif
		default:
			break;
		}

		xprt = next;
	}

	/* now remove sr_rec */
	rbtree_x_cached_remove(&svc_rqst_set.xt, t, &sr_rec->node_k,
			       sr_rec->id_k);
	mutex_unlock(&t->mtx);

	switch (sr_rec->ev_type) {
#if defined(TIRPC_EPOLL)
	case SVC_EVENT_EPOLL:
		close(sr_rec->ev_u.epoll.epoll_fd);
		mem_free(sr_rec->ev_u.epoll.events,
			 sr_rec->ev_u.epoll.max_events *
			 sizeof(struct epoll_event));
		break;
#endif
	default:
		/* XXX */
		break;
	}
	sr_rec->states = SVC_RQST_STATE_DESTROYED;
	/*	ref count here should be 2:
	 *	1	initial create/rbt ref we just deleted
	 *	+1	lookup (top of this routine through here)
	 * so, DROP one ref here so the final release will go to 0.
	 */
	--(sr_rec->refcnt);	/* DROP one extra ref - initial create */
	svc_rqst_release(sr_rec);
	return (code);
}

void
svc_rqst_shutdown(void)
{
	if (__svc_params->ev_u.evchan.id) {
		svc_rqst_delete_evchan(__svc_params->ev_u.evchan.id);
		__svc_params->ev_u.evchan.id = 0;
	}
}
