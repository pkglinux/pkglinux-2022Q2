#define PROGNAME "man2html"
#define VERSION "man-1.6g-schemedoc"
